from flask import Flask, render_template, request, flash, url_for, redirect, session
from dbhelper import *

app = Flask(__name__)
app.secret_key = "!@@#$"

header = ['idno', 'lastname', 'firstname', 'course', 'level', 'action']

@app.route("/home")
def home() -> None:
    if "username" in session:
        slist = getAll('student')
        return render_template("login.html", title="USER LOGIN", data=slist)
    else:
        flash("login properly")
        return render_template("login.html")

@app.route("/logout")
def logout() -> None:
    if "lastname" in session:
        session.pop("lastname", None)
        flash("You are logged out!")
        return render_template("login.html")

@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response

@app.route("/login", methods=['POST', 'GET'])
def login() -> None:
    if request.method == "POST":
        # GET THE INPUTTED VALUES
        uname = request.form['username']
        pword = request.form['password']
        #
        user = userlogin('user', username=uname, password=pword)
        if len(user) > 0:
            session['username'] = uname
            return redirect(url_for("home"))
        else:
            flash("Invalid User")
            return render_template("login.html", title="USER LOGIN")
    else:  # GET method
        return render_template("login.html", title="USER LOGIN")

@app.route("/")
def main() -> None:
    return render_template("index.html", title="Student List")

if __name__ == "__main__":
    app.run(debug=True)
