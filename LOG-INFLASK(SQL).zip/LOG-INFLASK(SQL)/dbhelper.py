import sqlite3

database:str = 'studentdb_booc'
def connect():
    return sqlite3.connect(database)

def getprocess(sql:str)->list:
    conn=connect()
    conn.row_factory=sqlite3.Row #return a dictionary formatted data
    cursor = conn.cursor()
    cursor.execute(sql)
    rows=cursor.fetchall()
    cursor.close()
    return rows
    
def getall(table_name:str)->list:
    sql:str= f"SELECT * FROM `{table_name}`"
    return getprocess(sql)
    
def userlogin(table_name:str,**kwargs)->bool:
    sql:str =""
    for key,value in kwargs.items():
        sql = f"SELECT * FROM {table_name} WHERE {key} = {value}"
    return getprocess(sql)
    
def main()->None:
    rows = getall('student')
    for row in rows:
        print(dict(row))
        
if __name__=='__main__':
    main()
        