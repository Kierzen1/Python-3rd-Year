from flask import Flask,render_template,request,redirect,url_for,flash,session
from dbhelper import *

app = Flask(__name__)
app.secret_key = "!@#$%"
head:list = ['idno','lastname','firstname','course','level','action']


imagefolder = "static/img"
app.config["UPLOAD_FOLDER"] = imagefolder


@app.route("/savestudent", methods=['POST'])
def savestudent() -> None:
    flag: str = request.form['flag']
    print(flag)
    if "username" in session:
        student_email = request.form.get('student_email')
        password = request.form.get('password')

        if flag == "False":
            ok: bool = addrecord('students', student_email=student_email, password=password)
            if ok:
                flash("New Student Added")
            return redirect("register")
        else:
            ok: bool = updaterecord('students', student_email=student_email, password=password)
            if ok:
                flash("Student Updated")
            return redirect("register")
    else:
        flash("Login Properly")
        return redirect(url_for("login"))



@app.route("/register", methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        student_email = request.form['student_email']
        password = request.form['password']
        
        addrecord('students', student_email=student_email, password=password)
        flash("Registration Successful")
        return redirect(url_for("home"))
    
    registered_users = getall('students')
    return render_template("register.html", title="register", registered_users=registered_users)


    
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
	
@app.route("/logout")
def logout()->None:
	if "username" in session:
		session.pop("username")
		flash("Logged Out")
	return render_template("index.html",title="my flask app")
	
	
@app.route("/home")
def home()->None:
	if "username" in session:
		slist = getall('students')
		return render_template("home.html",title="home",data=slist,header=head)
	else:
		flash("Login Properly")
		return render_template("index.html")

@app.route("/login",methods=['POST','GET'])
def login()->None:
	if request.method == "POST":
		uname:str = request.form['username']
		pword:str = request.form['password']
		#set a static user validation
		user:list = userlogin('user',username=uname,password=pword)
		print(dict(user[0]))
		if len(user)>0:
			session['username'] = uname
			return redirect(url_for("home"))
		else:
			flash("Invalid User")
			return render_template("login.html",title="student v1.0")
	else:
		return render_template("login.html",title="student v1.0")


@app.route("/")
def main()->None:
	return render_template("login.html",title="my flask app")
	
if __name__=="__main__":
	app.run(host="0.0.0.0",debug=True)
	
	
	