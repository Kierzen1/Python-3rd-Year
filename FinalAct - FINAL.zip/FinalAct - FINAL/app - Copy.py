from flask import Flask,render_template,request,redirect,url_for,flash,session, g
from dbhelper import *

app = Flask(__name__)
app.secret_key = "!@#$%"
head:list = ['idno','lastname','firstname','course','level','action']
DATABASE = 'finaldb.db'

imagefolder = "static/img"
app.config["UPLOAD_FOLDER"] = imagefolder

@app.route('/')
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()
def index():
    # Fetch data from the database and pass it to the template
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM registered_emails")
    rows = cursor.fetchall()
    return render_template('your_template.html', rows=rows)

@app.route('/save', methods=['POST'])
def save_picture():
    # Save data to the database
    email = request.form['email']
    password = request.form['password']
    # Save email, password, and image path to the database
    cursor = get_db().cursor()
    cursor.execute("INSERT INTO registered_emails (email, password, image_path) VALUES (?, ?, ?)",
                   (email, password, 'path/to/your/image'))
    get_db().commit()
    return redirect(url_for('index'))

@app.route("/register")
def register()->None:
    return render_template("register.html", title="register")

@app.route("/saveimage", methods=['GET','POST'])
def saveimage()->None:
    image = request.filess['webcam']
    name = request.args.get('iname')
    filename = imagefolder+"/"+name+".jpg"
    file.save(filename)
    return redirect(url_for("register"))
    
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
	
@app.route("/logout")
def logout()->None:
	if "username" in session:
		session.pop("username")
		flash("Logged Out")
	return render_template("index.html",title="my flask app")
	


@app.route("/savestudent",methods=['POST'])
def savestudent()->None:
	flag:str = request.form['flag']
	print(flag)
	if "username" in session:
		idno:str = request.form['idno']
		lastname:str = request.form['lastname']
		firstname:str = request.form['firstname']
		course:str = request.form['course']
		level:str = request.form['level']
		if flag == "False":
			ok:bool = addrecord('student',idno=idno,lastname=lastname,firstname=firstname,course=course,level=level)
			if ok:
				flash("New Student Added")
			return redirect("home")
		else:
			ok:bool = updaterecord('student',idno=idno,lastname=lastname,firstname=firstname,course=course,level=level)
			if ok:
				flash("Student Updated")
			return redirect("home")
	else:
		flash("Login Properly")
		return redirect(url_for("login"))
		

	
	
@app.route("/deletestudent/<idno>")
def deletestudent(idno)->None:
	if "username" in session:
		ok:bool = deleterecord('student',idno=idno)
		if ok:
			flash("Student Deleted")
	#return render_template("home.html",title="home",data=slist,header=head)		
	return redirect(url_for("home"))	
	
@app.route("/home")
def home()->None:
	if "username" in session:
		slist = getall('student')
		return render_template("home.html",title="home",data=slist,header=head)
	else:
		flash("Login Properly")
		return render_template("index.html")

@app.route("/login",methods=['POST','GET'])
def login()->None:
	if request.method == "POST":
		uname:str = request.form['username']
		pword:str = request.form['password']
		#set a static user validation
		user:list = userlogin('user',username=uname,password=pword)
		print(dict(user[0]))
		if len(user)>0:
			session['username'] = uname
			return redirect(url_for("home"))
		else:
			flash("Invalid User")
			return render_template("login.html",title="student v1.0")
	else:
		return render_template("login.html",title="student v1.0")


@app.route("/")
def main()->None:
	return render_template("login.html",title="my flask app")
	
if __name__=="__main__":
	app.run(host="0.0.0.0",debug=True)
	
	
	