from flask import Flask,render_template,request,redirect,url_for,flash,session
from dbhelper import *

app = Flask(__name__)
app.secret_key = "!@#$%"
head:list = ['idno','lastname','firstname','course','level','action']


imagefolder = "static/img"
app.config["UPLOAD_FOLDER"] = imagefolder


@app.route("/saveimage",methods=['GET','POST'])
def saveimage()->None:
    
    file = request.files['webcam']
    name = request.args.get('iname')
    student_email = request.args.get('student_email')
    password = request.args.get('password')

    addrecord('students',student_email=student_email,password=password)
    students = getall('students')

    students = students[len(students)-1]
    
    filename = imagefolder+"/"+str(students ['student_email'])+".jpg"
    file.save(filename)
    flash("Successfully Registered")
    return redirect(url_for("register"))


@app.route("/register", methods=['POST', 'GET'])
def register():
    registered_users = getall('students')
    return render_template("register.html", title="register", registered_users=registered_users)


    
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
	
@app.route("/logout")
def logout()->None:
	if "username" in session:
		session.pop("username")
		flash("Logged Out")
	return render_template("index.html",title="my flask app")
	
	
@app.route("/home")
def home()->None:
	if "username" in session:
		slist = getall('students')
		return render_template("home.html",title="home",data=slist,header=head)
	else:
		flash("Login Properly")
		return render_template("index.html")

@app.route("/login",methods=['POST','GET'])
def login()->None:
	if request.method == "POST":
		uname:str = request.form['username']
		pword:str = request.form['password']
		#set a static user validation
		user:list = userlogin('user',username=uname,password=pword)
		print(dict(user[0]))
		if len(user)>0:
			session['username'] = uname
			return redirect(url_for("home"))
		else:
			flash("Invalid User")
			return render_template("login.html",title="student v1.0")
	else:
		return render_template("login.html",title="student v1.0")
        
@app.route("/login2", methods=['POST', 'GET'])
def login2() -> None:
    if request.method == "POST":
        student_email: str = request.form['student_email']
        password: str = request.form['password']
        # set a static user validation
        students = getall('students')
        user: list = userlogin('students', student_email=student_email, password=password)
        print(dict(students[0]))
        if len(students) > 0:
            session['student_email'] = student_email
            return render_template("login_student.html", title="student v1.0")
        else:
            flash("Invalid User")
            return render_template("login_student.html", title="student v1.0")
    else:
        return render_template("login_student.html", title="student v1.0")


@app.route("/")
def main()->None:
	return render_template("index.html",title="my flask app")
	
if __name__=="__main__":
	app.run(host="0.0.0.0",debug=True)
	
	
	