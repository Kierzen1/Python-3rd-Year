from os import system

def main():
    system("cls")
    course = 'Pythons for "3rd Year"'
    email = ''' HI yers
    aasd
    asd
    asd
    '''
    course2 = 'Python for Beginners'
       #       01234            -1
    #index of pytyhon
    print(course2[-1])
    print(course2[-2]) 
    print(course2[0:3])
    print(course2 [1:])
    print(course2 [:5])
    print(course2 [0:-2])
if __name__ == "__main__":
    main()