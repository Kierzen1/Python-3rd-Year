"""
	block comment
	create a python program that would display the
	sum of two()
"""
#this is a comment

a=10
b=20
c=a+b
print(f"the sum of %d and %d is %d" % (a,b,c))