marks = [55, 64, 75]

length = len(marks)
print("Length is", length)

marks_sum = sum(marks)
print("The total marks you got is", marks_sum)