# create a set of integer type
student_id = {112, 114, 116, 118, 115}
student_id.add(123)#ADD
student_id.discard(118)#REMOVE
print('Student ID:', student_id)


# create a set of string type
vowel_letters = {'a', 'e', 'i', 'o', 'u'}
vowel_letters.add('z')#add
print('Vowel Letters:', vowel_letters)

