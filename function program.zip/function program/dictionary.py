# creating a dictionary
country_capitals = {
  "United States": "Washington D.C.", 
  "Italy": "Rome", 
  "England": "London"
}

# printing the dictionary
print(country_capitals)
#DICTIONARY LENGTH
country_capitals = {
  "United States": "Washington D.C.", 
  "Italy": "Rome", 
  "England": "London"
}

# get dictionary's length
print(len(country_capitals)) # 3

#CHANGE DICTIONARY ITEMS
country_capitals = {
  "United States": "Washington D.C., 
  "Italy": "Naples", 
  "England": "London"
}

# change the value of "Italy" key to "Rome"
country_capitals["Italy"] = "Rome"

print(country_capitals)

#ADD DICTIONARY ITEMS
country_capitals = {
  "United States": "Washington D.C.", 
  "Italy": "Naples" 
}

# add an item with "Germany" as key and "Berlin" as its value
country_capitals["Germany"] = "Berlin"

print(country_capitals)

#REMOVE DICTIONARY ITEMS
country_capitals = {
  "United States": "Washington D.C.", 
  "Italy": "Naples" 
}

# delete item having "United States" key
del country_capitals["United States"]


print(country_capitals)

country_capitals = {
  "United States": "Washington D.C.", 
  "Italy": "Naples" 
}

# print dictionary keys one by one
for country in country_capitals:
    print(country)

print("----------")

#ITERATING ONE BY ONE
# print dictionary values one by one
for country in country_capitals:
    capital = country_capitals[country]
    print(capital)