
def lists()->None:
    numbers = list(range(20))
    print(numbers[::2])
    odd = numbers[::2]
    reverse = print(odd[::-1])
def main()->None:
    lists()
if __name__ == "__main__":
    main()