def main()->None:
    s1 = {1, 2, 3, 4, 5}
    s1.add(6)
    print(s1)

if __name__=="__main__":
    main()