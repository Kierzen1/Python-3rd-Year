from flask import Flask,render_template

app = Flask (__name__)
filename:str= "student.csv"
header = ['idno','lastname','firstname','course','level','action']
def getall()->list:
    file = open(filename)
    data:list = file.readlines()
    file.close()
    return data
@app.route("/")
def main()->None:
    slist:list = getall()
    return render_template("index.html", pagetitle = "Student List", studentlist=slist,header=header)
if __name__=="__main__":
	app.run(debug=True)