from flask import Flask, render_template
from mysql.connector import connect

app = Flask(__name__)

head = ['','IDNO', 'lastname', 'firstname', 'course', 'level']


def db_connect() -> object:
    return connect(
        host="localhost",
        user="root",
        password="",
        database="python_booc"
    )


def get_process(sql: str) -> list:
    db = db_connect()
    cursor = db.cursor(dictionary=True)
    cursor.execute(sql)
    return cursor.fetchall()


def fetch_records(table_name: str):
    sql = f"SELECT * FROM `{table}`"
    return get_process(sql)


@app.route("/")
def main():
    table_name = "student"  # Replace with your actual table name
    records = fetch_records(table_name)
    return render_template("index.html", title="Student List", records=records, header=head)


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)
