from flask import Flask,render_template,request,redirect,url_for,flash,session
from dbhelper import *

app = Flask(__name__)
app.secret_key = "!@#$%"
head:list = ['idno','lastname','firstname','course','level','action']


imagefolder = "static/img"
app.config["UPLOAD_FOLDER"] = imagefolder



def create_db():
    # Creating the SQLite database and the student table
    conn = sqlite3.connect('finals.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT,
            password TEXT,
            image_path TEXT
        )
    ''')
    conn.commit()
    conn.close()


create_db()


@app.route("/register")
def register():
    return render_template("register.html", title="register")


@app.route("/saveimage", methods=['POST'])
def save_image():
    if request.method == 'POST':
        idno = request.form['idno']
        lastname = request.form['lastname']
        image = request.files['webcam']

        # Save image to the server
        image_name = f"{idno}_{lastname}_{firstname}.jpg"
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_name)
        image.save(image_path)

        # Save data to the database
        add_record('students', idno=idno, lastname=lastname, firstname=firstname, course=course, level=level,
                   image_path=image_path)

        flash("New Student Added")
        return redirect(url_for("home"))


@app.route("/savestudent", methods=['POST'])
def save_student():
    flag = request.form['flag']
    print(flag)
    if "username" in session:
        email = request.form['email']
        password = request.form['password']
        

        if flag == "False":
            addrecord('students', email=email, password=password)
            flash("New Student Added")
        else:
            updaterecord('students', email=email, password=password)
            flash("Student Updated")

        return redirect("register")
    else:
        flash("Login Properly")
        return redirect(url_for("login"))
    
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
	
@app.route("/logout")
def logout()->None:
	if "username" in session:
		session.pop("username")
		flash("Logged Out")
	return render_template("index.html",title="my flask app")
	
	
@app.route("/home")
def home()->None:
	if "username" in session:
		slist = getall('students')
		return render_template("home.html",title="home",data=slist,header=head)
	else:
		flash("Login Properly")
		return render_template("index.html")

@app.route("/login",methods=['POST','GET'])
def login()->None:
	if request.method == "POST":
		uname:str = request.form['username']
		pword:str = request.form['password']
		#set a static user validation
		user:list = userlogin('user',username=uname,password=pword)
		print(dict(user[0]))
		if len(user)>0:
			session['username'] = uname
			return redirect(url_for("home"))
		else:
			flash("Invalid User")
			return render_template("login.html",title="student v1.0")
	else:
		return render_template("login.html",title="student v1.0")


@app.route("/")
def main()->None:
	return render_template("login.html",title="my flask app")
	
if __name__=="__main__":
	app.run(host="0.0.0.0",debug=True)
	
	
	