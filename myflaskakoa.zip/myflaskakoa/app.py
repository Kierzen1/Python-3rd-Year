from flask import Flask,render_template,request,redirect,url_for,flash,session
from dbhelper import *

app = Flask(__name__)
app.secret_key = "!@#$%"
head:list = ['idno','lastname','firstname','course','level','action']
	
	
        
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
	
@app.route("/logout")
def logout()->None:
	if "username" in session:
		session.pop("username")
		flash("Logged Out")
	return render_template("index.html", title="my flask app" )
   
@app.route("/deletestudent/<idno>")
def deletestudent(idno)->None:
    if "username" in session:
        slist = getall('student')
        ok:bool = deleterecord('student',idno=idno)
        if ok:
            flash("student Deleted")
    return render_template("home.html",title="home",data=slist,header=head)
        
@app.route("/addstudent", methos = ['POST'])
def addstudent()->None:
    idno:str = request.form['idno']
    idno:str = request.form['idno']
    idno:str = request.form['idno']
    idno:str = request.form['idno']
    
    ok:bool = addrecord('student', idno = idno, lastname = lastnam #etc)

@app.route("/home")
def home()->None:
	if "username" in session:
		slist = getall('student')
		return render_template("home.html",title="home",data=slist,header=head)
	else:
		flash("Login Properly")
		return render_template("login.html")

@app.route("/login",methods=['POST','GET'])
def login()->None:
	if request.method == "POST":
		uname:str = request.form['username']
		pword:str = request.form['password']
		#set a static user validation
		user:list = userlogin('user',username=uname,password=pword)
		print(dict(user[0]))
		if len(user)>0:
			session['username'] = uname
			return redirect(url_for("home"))
		else:
			flash("Invalid User")
			return render_template("login.html",title="student v1.0")
	else:
		return render_template("login.html",title="student v1.0")


@app.route("/")
def main()->None:
	return render_template("index.html", title = "my flask app")
	
if __name__=="__main__":
	app.run(host="0.0.0.0",debug=True)
	
	
	