import sqlite3

database:str = "students.db"

def connect():
	return sqlite3.connect(database)

def getprocess(sql:str)->list:
	conn = connect()
	conn.row_factory = sqlite3.Row # to return a dictionary formatted data
	cursor = conn.cursor()
	cursor.execute(sql)
	rows = cursor.fetchall()
	cursor.close()
	return rows
	
def doprocess(sql:str)->bool:
	conn = connect()
	conn.row_factory = sqlite3.Row # to return a dictionary formatted data
	cursor = conn.cursor()
	cursor.execute(sql)
	conn.commit()
	cursor.close()
	return True if cursor.rowcount>0 else False
	
def deleterecord(table:str,**kwargs)->bool:
	sql:str = ""
	for key,value in kwargs.items():
		sql = f"DELETE FROM `{table}` WHERE `{key}` = '{value}'"
	return doprocess(sql)
	

def addrecord(table: str, **kwargs) -> bool:
    if table == 'students':
        student_email = kwargs.get('student_email', '')
        password = kwargs.get('password', '')
        student_name = kwargs.get('student_name', '')  # New field

        return doprocess(
            f"INSERT INTO `{table}`(`student_email`, `password`, `student_name`) "
            f"VALUES ('{student_email}', '{password}', '{student_name}')"
        )

def get_student_email_by_id(user_id):
    query = "SELECT student_email FROM students WHERE idno = ?"
    
    with sqlite3.connect(database) as conn:
        cursor = conn.cursor()
        cursor.execute(query, (user_id,))
        result = cursor.fetchone()

    if result:
        return result[0]
    else:
        return None
	
def updaterecord(table:str,**kwargs)->bool:
	keys:list = list(kwargs.keys())
	vals:list = list(kwargs.values())
	flds:list = []
	for i in range(1,len(keys)):
		flds.append(f"`{keys[i]}`='{vals[i]}'")
	fld:str = ",".join(flds)
	sql:str = f"UPDATE `{table}` SET {fld} WHERE `{keys[0]}`='{vals[0]}'"
	print(sql)
	return doprocess(sql)
	
def getall(table: str) -> list:
    if table == 'students':
        return getprocess(f"SELECT * FROM `{table}`")
        
def getAttendance(table: str) -> list:
    if table == 'attendance_records':
        return getprocess(f"SELECT * FROM `{table}`")
	
def userlogin(table:str,**kwargs)->bool:
	sql:str = ""
	for key,value in kwargs.items():
		sql = f"SELECT * FROM `{table}` WHERE `{key}` = '{value}'"
	return getprocess(sql)
	
	

def main()->None:
	rows = getall('student')
	for row in rows:
		print(dict(row))

if __name__=="__main__":
	main()
	