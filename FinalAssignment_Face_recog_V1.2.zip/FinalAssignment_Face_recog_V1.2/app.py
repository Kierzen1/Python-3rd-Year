from flask import Flask,render_template,request,redirect,url_for,flash,session, Response
from dbhelper import *
from datetime import datetime
import cv2
import numpy as np
import face_recognition
import sqlite3
import os


app = Flask(__name__)
app.secret_key = "!@#$%"
head:list = ['idno','lastname','firstname','course','level','action']


imagefolder = "static/img"
IMAGE_FOLDER = 'static/img' 
app.config["UPLOAD_FOLDER"] = imagefolder


@app.route("/saveimage",methods=['GET','POST'])
def saveimage()->None:
    
    file = request.files['webcam']
    name = request.args.get('iname')
    student_email = request.args.get('student_email')
    student_name = request.args.get('student_name')
    password = request.args.get('password')

    addrecord('students',student_email=student_email,student_name=student_name,password=password)
    students = getall('students')

    students = students[len(students)-1]
    
    filename = imagefolder+"/"+str(students ['student_name'])+".jpg"
    file.save(filename)
    flash("Successfully Registered")
    return redirect(url_for("register"))


@app.route("/register", methods=['POST', 'GET'])
def register():
    registered_users = getall('students')
    return render_template("register.html", title="register", registered_users=registered_users)


    
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
	
@app.route("/logout")
def logout()->None:
	if "student_email" in session:
		session.pop("student_email")
		flash("Logged Out")
	return render_template("login_student.html",title="Final Assignment 1")
	
	
@app.route("/home")
def home()->None:
	if "username" in session:
		slist = getall('students')
		return render_template("home.html",title="home",data=slist,header=head)
	else:
		flash("Login Properly")
		return render_template("index.html")

@app.route("/login",methods=['POST','GET'])
def login()->None:
	if request.method == "POST":
		uname:str = request.form['username']
		pword:str = request.form['password']
		#set a static user validation
		user:list = userlogin('user',username=uname,password=pword)
		print(dict(user[0]))
		if len(user)>0:
			session['username'] = uname
			return redirect(url_for("home"))
		else:
			flash("Invalid User")
			return render_template("login.html",title="student v1.0")
	else:
		return render_template("login.html",title="student v1.0")
        
@app.route("/login2", methods=['POST', 'GET'])
def login2() -> None:
    if request.method == "POST":
        student_email: str = request.form['student_email']
        password: str = request.form['password']
        # set a static user validation
        students = getall('students')
        user: list = userlogin('students', student_email=student_email, password=password)
        print(dict(students[0]))
        if user:
            session['student_email'] = student_email
            flash("Pic Displayed")
        else:
            flash("Register First")
        return render_template("login_student.html", title="Final Assignment 1")
    else:
        return render_template("login_student.html", title="Final Assignment 1")

@app.route('/attendance')
def index():
    attendance_records = getAttendance('attendance_records')
    return render_template('index_camera.html', title = 'Attendance Checker', attendance_records=attendance_records)

def load_known_faces():
    known_faces = []
    for filename in os.listdir(IMAGE_FOLDER):
        if filename.endswith('.jpg') or filename.endswith('.png'):
            student_email = os.path.splitext(filename)[0]  
            image_path = os.path.join(IMAGE_FOLDER, filename)
            known_faces.append((student_email, image_path)) 
    return known_faces

recognized_faces = set()    

def generate_frames():
    video_capture = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    known_faces = load_known_faces()

    while True:
        success, frame = video_capture.read()
        if not success:
            break

        face_locations = face_recognition.face_locations(frame)
        face_encodings = face_recognition.face_encodings(frame, face_locations)

        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            for student_email, image_path in known_faces:
                known_face_image = face_recognition.load_image_file(image_path)
                known_face_encoding = face_recognition.face_encodings(known_face_image)[0]
                results = face_recognition.compare_faces([known_face_encoding], face_encoding)

                if results[0] and student_email not in recognized_faces:
                    # Face recognized, update the database
                    with sqlite3.connect(database) as conn:
                        cursor = conn.cursor()

                        # Insert record into recognized_faces table
                        cursor.execute('INSERT INTO recognized_faces (user_id, timestamp) VALUES (?, ?)',
                                       (student_email, datetime.now()))

                        # Insert record into attendance_records table
                        cursor.execute('INSERT INTO attendance_records (student_email, timestamp) VALUES (?, ?)',
                                       (student_email, datetime.now()))

                        conn.commit()

                    recognized_faces.add(student_email)  # Add the recognized face to the set

                    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)

                    name_without_extension = os.path.splitext(os.path.basename(image_path))[0]
                    text_position = (left + 6, bottom - 6)
                    cv2.putText(frame, name_without_extension, text_position, cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                                (255, 255, 255), 1)

        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    video_capture.release()



@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')
    
@app.route("/")
def main()->None:
	return redirect(url_for("register"))
	
if __name__=="__main__":
	app.run(host="0.0.0.0",debug=True)
	
	
	