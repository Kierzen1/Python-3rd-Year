import sqlite3

database: str = "mystudentdb.db"


def connect():
    return sqlite3.connect(database)


def saverecord(data: dict) -> int:
    conn = connect()
    flag: str = data.get("flag")
    idno: str = data.get("idno")
    lastname: str = data.get("lastname")
    firstname: str = data.get('firstname')
    course: str = data.get("course")
    level: str = data.get("level")
    try:
        sql: str = ""
        if '-' in flag:
            sql = f"INSERT INTO `student` (`idno`,`lastname`,`firstname`,`course`,`level`) VALUES ('{idno}','{lastname}','{firstname}','{course}','{level}')"
        else:
            sql = f"UPDATE `student` SET idno='{idno}',lastname='{lastname}',firstname='{firstname}',course='{course}',level='{level}' WHERE id='{flag}'"
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        cursor.close()
    except Exception:
        return 1 
    if '-' in flag:
        return 0
    else:
        return 2



def deleterecord(idno: int)->bool:
        conn = connect()
        sql: str = f"DELETE FROM `student` WHERE `id`={idno}"
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        cursor.close()



def getprocess(sql: str) -> list:
    conn = connect()
    conn.row_factory = sqlite3.Row  # to return a dictionary formatted data
    cursor = conn.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    cursor.close()
    return rows


def getall(table: str) -> list:
    sql: str = f"SELECT * FROM `{table}`"
    return getprocess(sql)


def userlogin(table: str, **kwargs) -> bool:
    sql: str = ""
    for key, value in kwargs.items():
        sql = f"SELECT * FROM `{table}` WHERE `{key}` = '{value}'"
    return getprocess(sql)


def main() -> None:
    rows = getall('student')
    for row in rows:
        print(dict(row))


if __name__ == "__main__":
    main()
